
function genDivs(v){  
  
var v = document.getElementById("name").value;//take grid column value as you want
var e = document.getElementById("inv"); // whatever you want to append the rows to: 
var elements =  document.querySelectorAll("div.row, style");
for(var i = 0; i < elements.length; i++){
  elements[i].parentNode.removeChild(elements[i]);}
      for(var i = 0; i < v; i++){ 
        var row = document.createElement("div"); 
        row.className  = "row"; 
        row.id = "c"+(i + 1);
        for(var x = 1; x <= 1; x++){ 
            var cell = document.createElement("div"); 
            cell.id = "d"+(i + x); 
            cell.className  = "cell";
            row.appendChild(cell);
            for(var p = 1; p <= 1; p++){ 
              var img = document.createElement("img"); 
              img.id = "e"+(i + p); 
              cell.appendChild(img); 
          } 
        } 
        e.appendChild(row); 
      }

      var l ="padding-left: 28px;margin-left: -28px;";
      var r ="padding-right: 28px;margin-right: -28px;";
      var t ="padding-top: 28px;margin-top: -28px;";
      var b ="padding-bottom: 28px;margin-bottom: -28px;";
      var b1="background: url('inventory1.png');";
      var b2="background: url('inventory2.png');";
      var b3="background: url('inventory3.png');";
      var b4="background: url('inventory4.png');";
      var b5="background: url('inventory5.png');";
      var b6="background: url('inventory6.png');";
      var base ="width: 72px; height: 72px; background-repeat:no-repeat;display: inline-block;}";
      var sheet = document.createElement('style')
      document.body.appendChild(sheet);

      if(v<10){
        if(v>1){
        for(l1=1;l1<v-1;l1++){
          sheet.append("#c"+(v-l1)+" {"+t+b+b2+base);
          }
          sheet.append("#c1 {"+l+t+b+b1+base);
          sheet.append("#c"+v+"{"+r+t+b+b2+base);
        } else if(v==1){
          sheet.append("#c1 {"+r+l+t+b+b1+base);
        }
      } else if(v>9&&v<18){

        sheet.append("#c1 {"+l+t+b1+base);
        for(l1=2;l1<v-8;l1++){
          sheet.append("#c"+l1+ "{"+t+b2+base);
      }
        for(l2=math.floor(v/9)-1;l2>0;l2--){;
          sheet.append("#c"+(l2*9+1)+ "{"+l+b3+base);
        }
        sheet.append("#c"+v+ "{"+b+r+b6+base);
        if (v==10){
          sheet.append("#c"+(v-v%9+1)+ "{"+l+b+b5+base);
        } else{
          sheet.append("#c"+(v-v%9+1)+ "{"+l+b+b3+base);
        }
        sheet.append("#c"+(v-v%9)+ "{"+r+t+b+b2+base);
        for(l3=v-1;l3>(v-v%9+1);l3--){
          sheet.append("#c"+l3+ "{"+b+b4+base);
        }
        for(l6=v-8;l6<(v-v%9);l6++){
          sheet.append("#c"+l6+ "{"+t+b+b2+base);
        }

      } else if(v>17){
            sheet.append("#c1 {"+l+t+b1+base);
            for(l1=2;l1<9;l1++){
              sheet.append("#c"+l1+ "{"+t+b2+base);
          }
          sheet.append("#c9 {"+r+t+b2+base);
          for(l3=math.floor(v/9)-1;l3>1;l3--){
            sheet.append("#c"+(l3*9)+ "{"+r+b4+base);
          }
          for(l4=1;l4<v-8;l4++){
            if(l4>10 && l4%9!==1 && l4%9!==0){
            sheet.append("#c"+l4+ "{"+r+b4+base);
            }
          }
          
          /*koncowki*/
          if (v%9==0)
          {
            for(l2=math.floor(v/9)-2;l2>0;l2--){
              sheet.append("#c"+(l2*9+1)+ "{"+l+b3+base);
            }
            sheet.append("#c"+v+ "{"+b+r+b4+base);
            sheet.append("#c"+(v-8)+ "{"+b+l+b3+base);
            for(l5=1;l5<8;l5++){
              sheet.append("#c"+(v-l5)+ "{"+b+b4+base);
            }
          } else if (v%9==1)
          {
            for(l2=math.floor(v/9)-1;l2>0;l2--){
              sheet.append("#c"+(l2*9+1)+ "{"+l+b3+base);
            }
            sheet.append("#c"+v+ "{"+l+b+r+b5+base);
            sheet.append("#c"+(v-1)+ "{"+b+r+b4+base);
            for(l5=2;l5<9;l5++){
              sheet.append("#c"+(v-l5)+ "{"+b+b4+base);
            }
            
          } else if (v%9>1)
          {
            for(l2=math.floor(v/9)-1;l2>0;l2--){
              sheet.append("#c"+(l2*9+1)+ "{"+l+b3+base);
            }
            sheet.append("#c"+v+ "{"+b+r+b6+base);
            sheet.append("#c"+(v-v%9+1)+ "{"+l+b+b3+base);
            sheet.append("#c"+(v-v%9)+ "{"+r+b+b4+base);
            for(l5=v-1;l5>(v-v%9+1);l5--){
              sheet.append("#c"+l5+ "{"+b+b4+base);
            }
            for(l6=v-8;l6<(v-v%9);l6++){
              sheet.append("#c"+l6+ "{"+b+b4+base);
            }         
          } 
        }    
}